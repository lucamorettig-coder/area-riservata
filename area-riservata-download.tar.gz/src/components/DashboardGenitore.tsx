import ListaBambini from './ListaBambini';
import ListaIscrizioni from './ListaIscrizioni';
import { baseUrl } from '../lib/base-url';

interface GenitoreData {
  NOME_GENITORE: string;
  COGNOME_GENITORE: string;
  DATA_NASCITA_GENITORE: string;
  LUOGO_NASCITA_GENITORE: string;
  CODICE_FISCALE_GENITORE: string;
  VIA_RESIDENZA_GENITORE: string;
  CITTA_RESIDENZA_GENITORE: string;
  EMAIL_GENITORE: string;
  CELLULARE_GENITORE: string;
}

interface DashboardGenitoreProps {
  genitore: GenitoreData;
}

// Componente helper per i campi dati
const InfoField = ({ label, value, className = "" }: { label: string; value: string; className?: string }) => (
  <div className={`flex flex-col gap-1 ${className}`}>
    <span className="text-xs font-bold text-slate-500 uppercase tracking-wide">
      {label}
    </span>
    <span className="text-base font-medium text-slate-800 break-words">
      {value || "-"}
    </span>
  </div>
);

// Componente helper per le icone rotonde
const SectionIcon = ({ children }: { children: React.ReactNode }) => (
  <div className="w-10 h-10 rounded-full bg-blue-900 flex items-center justify-center text-white shrink-0">
    {children}
  </div>
);

export default function DashboardGenitore({ genitore }: DashboardGenitoreProps) {
  const formatDate = (dateString: string) => {
    if (!dateString) return "-";
    const date = new Date(dateString);
    return date.toLocaleDateString('it-IT', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric'
    });
  };

  const handleLogout = async () => {
    try {
      await fetch(`${baseUrl}/api/logout`, { method: 'POST' });
      window.location.href = `${baseUrl}/login`;
    } catch (error) {
      console.error('Errore durante il logout:', error);
    }
  };

  return (
    <div className="min-h-screen bg-white">
      {/* Override CSS per forzare gli stili dei pulsanti */}
      <style>{`
        .action-button {
          background-color: #1e3a8a !important; /* bg-blue-900 */
          color: white !important;
          border: none !important;
        }
        .action-button:hover {
          background-color: #1e40af !important; /* bg-blue-800 */
        }
      `}</style>

      <div className="max-w-5xl mx-auto p-4 sm:p-6 flex flex-col gap-8">
        
        {/* --- HEADER --- */}
        <div className="flex flex-row justify-between items-start gap-4">
          <div className="flex flex-col gap-1">
            <h3 className="text-2xl sm:text-3xl font-bold text-slate-900">
              Area Personale
            </h3>
            <p className="text-sm text-slate-600">
              Benvenuto/a, <span className="font-semibold text-slate-800">{genitore.NOME_GENITORE} {genitore.COGNOME_GENITORE}</span>
            </p>
          </div>
          
          <button
            onClick={handleLogout}
            className="inline-flex items-center justify-center w-10 h-10 p-2 rounded-md border border-slate-300 bg-white hover:bg-slate-50 transition-colors shrink-0"
            title="Esci"
            aria-label="Esci"
          >
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"></path>
              <polyline points="16 17 21 12 16 7"></polyline>
              <line x1="21" y1="12" x2="9" y2="12"></line>
            </svg>
          </button>
        </div>

        <hr className="border-slate-200" />

        {/* --- SEZIONE: I TUOI BAMBINI --- */}
        <section className="flex flex-col gap-6">
          <div className="flex items-center justify-between gap-4">
            <div className="flex items-center gap-3 min-w-0">
              <SectionIcon>
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <circle cx="12" cy="12" r="3"></circle>
                  <path d="M12 2v4m0 12v4M4.93 4.93l2.83 2.83m8.48 8.48l2.83 2.83M2 12h4m12 0h4M4.93 19.07l2.83-2.83m8.48-8.48l2.83-2.83"></path>
                </svg>
              </SectionIcon>
              <h4 className="text-xl sm:text-2xl font-bold text-slate-700 uppercase tracking-wide leading-none m-0 truncate">
                I tuoi bambini
              </h4>
            </div>

            <a
              href={`${baseUrl}/bambini/aggiungi`}
              className="action-button flex items-center justify-center gap-2 h-10 px-3 sm:px-6 rounded-full shrink-0 transition-colors no-underline font-semibold text-sm"
            >
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M5 12h14"/>
                <path d="M12 5v14"/>
              </svg>
              <span className="hidden sm:inline">Aggiungi</span>
            </a>
          </div>

          {/* ✅ Contenitore grigio uniforme */}
          <div className="bg-slate-100 rounded-3xl border border-slate-200 p-6 sm:p-8">
            <ListaBambini />
          </div>
        </section>

        <hr className="border-slate-200" />

        {/* --- SEZIONE: DATI ANAGRAFICI --- */}
        <section className="flex flex-col gap-6">
          <div className="flex items-center justify-between gap-4">
            <div className="flex items-center gap-3 min-w-0">
              <SectionIcon>
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"></path>
                  <circle cx="12" cy="7" r="4"></circle>
                </svg>
              </SectionIcon>
              <h4 className="text-xl sm:text-2xl font-bold text-slate-700 uppercase tracking-wide leading-none m-0 truncate">
                I tuoi dati
              </h4>
            </div>

            <a
              href={`${baseUrl}/modifica-profilo`}
              className="action-button flex items-center justify-center gap-2 h-10 px-3 sm:px-6 rounded-full shrink-0 transition-colors no-underline font-semibold text-sm"
            >
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M21.174 6.812a1 1 0 0 0-3.986-3.987L3.842 16.174a2 2 0 0 0-.5.83l-1.321 4.352a.5.5 0 0 0 .623.622l4.353-1.32a2 2 0 0 0 .83-.497z"/>
              </svg>
              <span className="hidden sm:inline">Modifica</span>
            </a>
          </div>

          <div className="bg-slate-100 rounded-3xl border border-slate-200 p-6 sm:p-8">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-y-6 gap-x-8">
              <InfoField label="Nome" value={genitore.NOME_GENITORE} />
              <InfoField label="Cognome" value={genitore.COGNOME_GENITORE} />
              <InfoField label="Data di nascita" value={formatDate(genitore.DATA_NASCITA_GENITORE)} />
              <InfoField label="Luogo di nascita" value={genitore.LUOGO_NASCITA_GENITORE} />
              <InfoField label="Codice Fiscale" value={genitore.CODICE_FISCALE_GENITORE} className="font-mono" />
              <div className="sm:col-span-2 grid grid-cols-1 sm:grid-cols-2 gap-y-6 gap-x-8">
                <InfoField label="Indirizzo" value={genitore.VIA_RESIDENZA_GENITORE} />
                <InfoField label="Città" value={genitore.CITTA_RESIDENZA_GENITORE} />
              </div>
              <InfoField label="Email" value={genitore.EMAIL_GENITORE} />
              <InfoField label="Cellulare" value={genitore.CELLULARE_GENITORE} />
            </div>
          </div>
        </section>

        <hr className="border-slate-200" />

        {/* --- SEZIONE: ISCRIZIONI --- */}
        <section className="flex flex-col gap-6">
          <div className="flex items-center justify-between gap-4">
            <div className="flex items-center gap-3 min-w-0">
              <SectionIcon>
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path>
                  <polyline points="14 2 14 8 20 8"></polyline>
                  <line x1="12" y1="18" x2="12" y2="12"></line>
                  <line x1="9" y1="15" x2="15" y2="15"></line>
                </svg>
              </SectionIcon>
              <h4 className="text-xl sm:text-2xl font-bold text-slate-700 uppercase tracking-wide leading-none m-0 truncate">
                Iscrizioni
              </h4>
            </div>

            <a
              href={`${baseUrl}/iscrizioni/nuova`}
              className="action-button flex items-center justify-center gap-2 h-10 px-3 sm:px-6 rounded-full shrink-0 transition-colors no-underline font-semibold text-sm"
            >
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M5 12h14"/>
                <path d="M12 5v14"/>
              </svg>
              <span className="hidden sm:inline">Nuova</span>
            </a>
          </div>

          {/* ✅ Contenitore grigio uniforme - bambinoId omesso (undefined) per mostrare tutte le iscrizioni del genitore */}
          <div className="bg-slate-100 rounded-3xl border border-slate-200 p-6 sm:p-8">
            <ListaIscrizioni 
              onSelectIscrizione={(id: string) => window.location.href = `${baseUrl}/iscrizioni/${id}`}
              onNuovaIscrizione={() => window.location.href = `${baseUrl}/iscrizioni/nuova`}
            />
          </div>
        </section>
      </div>
    </div>
  );
}
